import socket
#import SocketServer
import time


# receive data from the server 
#print(s.recv(1024).decode('utf8'))
def isspace(data):
	if((data==" ")or(data=="\n") ):
		return "space"
	else:
		return "alnum"

data=True
done="done"
rx_word=""
new_line="\n"
rx_data_list=[]
new_data=""
i=0


s = socket.socket()
port = 12346
s.connect(('127.0.0.1', port)) 

while data:
	new_data=""
	data=s.recv(1)
	#print(data)
	if(isspace(str(data))=="alnum"):
		rx_word+=str(data)
	else:
		#print("\nrx_word is "+rx_word)
		if(rx_word==done):
			#print rx_word
			#print("Detected done")
			break
		else:
			new_data+=rx_word+str(data)
			print new_data,
		rx_word=""
	
print("out of while loop")
#print(rx_data_list)
#print(rx_data_list[-1])
s.close()
