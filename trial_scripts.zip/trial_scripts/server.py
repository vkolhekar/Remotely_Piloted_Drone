import socket
import time

vehicle=0

s = socket.socket()        
port=12346
print ("Socket successfully created")
s.bind(('', port))         
print ("socket binded to %s" %(port) )
s.listen(5)      
print ("socket is listening" )
c, addr = s.accept()   
print ("Got connection from", addr )
c.send("Thank you for connecting \n")
time.sleep(3)
c.send("comment 1 \n")
time.sleep(3)
c.send("comment 2 \n")
time.sleep(3)
#c.send("done ")
c.send("comment 3 \n")
c.send("comment 4 \n")
c.send("comment 5 \n")
c.send("done ")
c.close()
